# Sistemas Operacionais - T03

## Trabalho Prático da Unidade 1 - Processos e Threads
### Professor: Gustavo Girão
### Aluno: André Augusto Fernandes
#
## Instruções:
### Para executar os códigos de forma automática, basta digitar:
### "`make e1`" para a implementação E1.
### ou
### "`make e2`" para a implementação E2.
#
### Acesse o:
### Relatório [aqui](relatorio.pdf)
### Vídeo https://www.youtube.com/watch?v=u2mNQbDSpKs
#
### Natal / 2022.2